import { createRouter, createWebHistory } from 'vue-router'
import UserList from '../views/UserList.vue'
import CustomerList from '../views/CustomerList.vue'
import MerchandiseList from '../views/MerchandiseList.vue'
import SupplierList from '../views/SupplierList.vue'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/users',
      name: 'users',
      component: UserList
    },
    {
      path: '/customers',
      name: 'customers',
      component: CustomerList
    },
    {
      path: '/merchandises',
      name: 'merchandises',
      component: MerchandiseList
    },
    {
      path: '/suppliers',
      name: 'suppliers',
      component: SupplierList
    },
    
  ]
})

export default router
