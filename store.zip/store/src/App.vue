<template>
  <div id="app">
    <h1>Riza's Sari Sari Store</h1>
    <div class="nav-links">
      <router-link class="nav-link" to="/users">User List</router-link>
      <router-link class="nav-link" to="/customers">Customer List</router-link>
      <router-link class="nav-link" to="/merchandises">Merchandise List</router-link>
      <router-link class="nav-link" to="/suppliers">Supplier List</router-link>
    </div>
    <div class="content">
      <router-view />
    </div>
  </div>
</template>

<script setup>
import { RouterLink, RouterView } from 'vue-router'
</script>

<style scoped>
#app {
  height: 100vh;
  width: 600vw;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  background: url('https://static.vecteezy.com/system/resources/previews/001/542/636/non_2x/fashion-clothes-store-background-free-vector.jpg') ;
  background-size: cover;
  background-repeat: no-repeat;
  background-color: yellow;
  padding: 20px;
  margin-left: -60px;
}

h1 {
  text-align: center;
  color: #fff;
  font-size: 50px;
  margin-bottom: 20px;
  text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
}

.nav-links {
  display: flex;
  justify-content: center;
  margin-bottom: 20px;
}

.nav-link {
  padding: 10px 20px;
  margin: 5px;
  text-decoration: none;
  color: #fff;
  border-radius: 30px;
  background-color: #ff6b6b;
  transition: all 0.3s ease;
}

.nav-link:hover {
  transform: translateY(-3px);
  box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
}

.content {
  padding: 20px;
  background-color: rgba(255, 255, 255, 0.9);
  border-radius: 15px;
  box-shadow: 0 0 15px rgba(0, 0, 0, 0.2);
  max-width: 800px;
  width: 100%;
}
</style>
