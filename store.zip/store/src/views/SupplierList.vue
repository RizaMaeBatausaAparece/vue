<template>
  <div>
    <h1>Supplier List</h1>
    <table>
      <thead>
        <tr>
          <th>ID</th>
          <th>Company Name</th>
          <th>Address</th>
          <th>Phone</th>
          <th>Contact Person</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="supplier in suppliers" :key="supplier.id">
          <td>{{ supplier.id }}</td>
          <td>{{ supplier.company_name }}</td>
          <td>{{ supplier.address }}</td>
          <td>{{ supplier.phone }}</td>
          <td>{{ supplier.contact_person }}</td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script>
import { ref, onMounted } from 'vue';
import axios from 'axios';

export default {
  setup() {
    const suppliers = ref([]);

    onMounted(async () => {
      try {
        const response = await axios.get('http://localhost:8000/api/suppliers');
        suppliers.value = response.data;
      } catch (error) {
        console.error('Error fetching suppliers:', error);
      }
    });

    return {
      suppliers,
    };
  },
};
</script>

<style scoped>
.supplier-list {
margin: 20px;
font-family: 'Arial', sans-serif;
}

h1 {
color: #ff7f50;
text-align: center;
font-family: 'Verdana', Geneva, sans-serif;
font-size: 32px;
margin-bottom: 15px;
}

table {
width: 100%;
border-collapse: separate;
border-spacing: 0;
margin-top: 10px;
}

th, td {
border: 2px solid #ff7f50;
padding: 12px;
text-align: left;
background-color: #fff7ef;
}

th {
background-color: #ffcdb2;
text-align: center;
font-weight: bold;
text-transform: uppercase;
letter-spacing: 1px;
}
</style>
