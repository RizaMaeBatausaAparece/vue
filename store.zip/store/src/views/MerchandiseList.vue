<template>
    <div>
      <h1>Merchandise List</h1>
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Brand</th>
            <th>Description</th>
            <th>Retail Price</th>
            <th>Whole Sale Price</th>
            <th>Wole Sale Qty</th>
            <th>Qty Stock</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="merchandise in merchandises" :key="merchandise.id">
            <td>{{ merchandise.id }}</td>
            <td>{{ merchandise.brand }}</td>
            <td>{{ merchandise.description }}</td>
            <td>{{ merchandise.retail_price }}</td>
            <td>{{ merchandise.whole_sale_price }}</td>
            <td>{{ merchandise.whole_sale_qty }}</td>
            <td>{{ merchandise.qty_stock }}</td>
          </tr>
        </tbody>
      </table>
    </div>
  </template>
  
  <script>
  import { ref, onMounted } from 'vue';
  import axios from 'axios';
  
  export default {
    setup() {
      const merchandises = ref([]);
  
      onMounted(async () => {
        try {
          const response = await axios.get('http://localhost:8000/api/merchandises');
          merchandises.value = response.data;
        } catch (error) {
          console.error('Error fetching merchandises:', error);
        }
      });
  
      return {
        merchandises,
      };
    },
  };
  </script>
  
   <style scoped>
.merchandise-list {
  margin: 20px;
  font-family: 'Arial', sans-serif;
}

h1 {
  color: #ff7f50;
  text-align: center;
  font-family: 'Verdana', Geneva, sans-serif;
  font-size: 32px;
  margin-bottom: 15px;
}

table {
  width: 100%;
  border-collapse: separate;
  border-spacing: 0;
  margin-top: 10px;
}

th, td {
  border: 2px solid #ff7f50;
  padding: 12px;
  text-align: left;
  background-color: #fff7ef;
}

th {
  background-color: #ffcdb2;
  text-align: center;
  font-weight: bold;
  text-transform: uppercase;
  letter-spacing: 1px;
}
</style>