<template>
  <div>
    <h1>User List</h1>
    <table>
      <thead>
        <tr>
          <th>ID</th>
          <th>Name</th>
          <th>Email</th>
          <th>Email Verified</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="user in users" :key="user.id">
          <td>{{ user.id }}</td>
          <td>{{ user.name }}</td>
          <td>{{ user.email }}</td>
          <td>{{ user.email_verified_at }}</td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import axios from 'axios';

const users = ref([]);

onMounted(async () => {
  try {
    const response = await axios.get('http://localhost:8000/api/users');
    users.value = response.data;
  } catch (error) {
    console.error('Error fetching users:', error);
  }
});

</script>

<style scoped>
.user-list {
margin: 20px;
font-family: 'Arial', sans-serif;
}

h1 {
color: #ff7f50;
text-align: center;
font-family: 'Verdana', Geneva, sans-serif;
font-size: 32px;
margin-bottom: 15px;
}

table {
width: 100%;
border-collapse: separate;
border-spacing: 0;
margin-top: 10px;
}

th, td {
border: 2px solid #ff7f50;
padding: 12px;
text-align: left;
background-color: #fff7ef;
}

th {
background-color: #ffcdb2;
text-align: center;
font-weight: bold;
text-transform: uppercase;
letter-spacing: 1px;
}
</style>